<title>"KFC" - conversion of temperature degrees on different scales</title>
<?php header('Content-Type: text/html; charset=utf-8');
/** Index - default
 *  Displays the result of the method index of controller in the DegreeTranslateController
 */

echo '<pre>', var_dump($degree), '</pre>';
